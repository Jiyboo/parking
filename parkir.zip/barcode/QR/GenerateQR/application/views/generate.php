<html>
<head>
	<meta charset="UTF-8">
	<title>Halaman Home</title>
</head>
<body>
	<img src="<?=base_url() ?>assets/QRCODE/<?=$img ?>" alt="">
</body>
</html>